import React from "react";
import { Typography, Row, Col, Space, Select, Divider } from "antd";

const { Title, Text, Link } = Typography;
const { Option } = Select;

const AppFooter = () => {
  const footerIcon = [
    "https://stake.com/_app/immutable/assets/litecoin.RPQ1704t.svg",
    "https://stake.com/_app/immutable/assets/bitcoin.DpHO7atL.svg",
    "https://stake.com/_app/immutable/assets/ethereum.yvHxjSL-.svg",
    "https://stake.com/_app/immutable/assets/tron.BYiII1T_.svg",
    "https://stake.com/_app/immutable/assets/dogecoin.k8OeA1SN.svg",
    "https://stake.com/_app/immutable/assets/bitcoin-cash.DUaEsStO.svg",
    "https://stake.com/_app/immutable/assets/tether.Cv3Qd73c.svg",
    "https://stake.com/_app/immutable/assets/hub88.CvKNQs2Q.svg",
    "https://stake.com/_app/immutable/assets/safe-gamble.Lrrm0l28.svg",
    "https://stake.com/_app/immutable/assets/betblocker.-t2TDIRS.svg",
    "https://stake.com/_app/immutable/assets/18plus.DgozareE.svg",
  ];

  const footerImage = [
    "https://stake.com/_app/immutable/assets/f1-logo.C8neaUBw.svg",
    "https://stake.com/_app/immutable/assets/everton-logo.DjZkLatD.svg",
    "https://stake.com/_app/immutable/assets/ufc-partner.C8Oj708g.svg",
  ];

  return (
    <Row
    //   style={{ backgroundColor: "#0f0f1b", color: "#ffffff" }}
    >
      <Col>
        <Row>
          <Col>
            <Row>
              <Text className="color-white footerTitle font-weight-500">
                Stake
              </Text>
            </Row>
            <Row className="color-grey">
              © 2024 Stake.com | All Rights Reserved.
            </Row>
          </Col>
        </Row>
        <Divider
          style={{ background: "#213743", padding: "0.5px", width: "80vw" }}
        />
        {/* Main Navigation Links */}
        <Row justify={"space-between"}>
          <Col>
            <Title level={5} style={{ color: "#ffffff" }}>
              Casino
            </Title>
            <Space
              direction="vertical"
              style={{ color: "#afb8d0", fontWeight: 500 }}
            >
              <div href="#">Casino Games</div>
              <div href="#">Slots</div>
              <div href="#">Live Casino</div>
              <div href="#">Roulette</div>
              <div href="#">Blackjack</div>
              <div href="#">Providers</div>
              <div href="#">Promos & Competitions</div>
            </Space>
          </Col>

          <Col>
            <Title level={5} style={{ color: "#ffffff" }}>
              Sports
            </Title>
            <Space
              direction="vertical"
              style={{ color: "#afb8d0", fontWeight: 500 }}
            >
              <div href="#">Sportsbook</div>
              <div href="#">Live Sports</div>
              <div href="#">Soccer</div>
              <div href="#">Basketball</div>
              <div href="#">Tennis</div>
              <div href="#">eSports</div>
              <div href="#">Bet Bonuses</div>
              <div href="#">Sports Rules</div>
              <div href="#">Racing Rules</div>
            </Space>
          </Col>

          <Col>
            <Title level={5} style={{ color: "#ffffff" }}>
              Support
            </Title>
            <Space
              direction="vertical"
              style={{ color: "#afb8d0", fontWeight: 500 }}
            >
              <div href="#">Help Center</div>
              <div href="#">Fairness</div>
              <div href="#">Gamble Aware</div>
              <div href="#">Live Support</div>
              <div href="#">Self Exclusion</div>
            </Space>
          </Col>

          <Col>
            <Title level={5} style={{ color: "#ffffff" }}>
              About Us
            </Title>
            <Space
              direction="vertical"
              style={{ color: "#afb8d0", fontWeight: 500 }}
            >
              <div href="#">VIP Club</div>
              <div href="#">Affiliate</div>
              <div href="#">Privacy Policy</div>
              <div href="#">AML Policy</div>
              <div href="#">Terms of Service</div>
            </Space>
          </Col>

          <Col>
            <Title level={5} style={{ color: "#ffffff" }}>
              Payment Info
            </Title>
            <Space
              direction="vertical"
              style={{ color: "#afb8d0", fontWeight: 500 }}
            >
              <div href="#">Deposit & Withdrawals</div>
              <div href="#">Currency Guide</div>
              <div href="#">Crypto Guide</div>
              <div href="#">Supported Crypto</div>
              <div href="#">How to Use the Vault</div>
              <div href="#">How Much to Bet With</div>
            </Space>
          </Col>

          <Col>
            <Title level={5} style={{ color: "#ffffff" }}>
              How-to Guides
            </Title>
            <Space
              direction="vertical"
              style={{ color: "#afb8d0", fontWeight: 500 }}
            >
              <div href="#">Online Casino Guide</div>
              <div href="#">Sports Betting Guide</div>
              <div href="#">How to Live Stream Sports</div>
              <div href="#">Stake VIP Guide</div>
              <div href="#">House Edge Guide</div>
            </Space>
          </Col>
          <Col>
            <Row>
              <Select
                defaultValue="English"
                style={{ width: 130, marginTop: "25px", height: 45 }}
              >
                <Option value="English">English</Option>
                <Option value="Spanish">Spanish</Option>
              </Select>
            </Row>
            <Row>
              <Select
                defaultValue="Decimal"
                style={{ width: 130, marginTop: "20px", height: 45 }}
              >
                <Option value="Decimal">Decimal</Option>
                <Option value="Fraction">Fraction</Option>
              </Select>
            </Row>
            <Row>
              <Text className="mt-10 color-grey">1 BTC = $75,987.84</Text>
            </Row>
          </Col>
        </Row>

        <Divider
          style={{ background: "#213743", padding: "0.5px", width: "80vw" }}
        />
        <Row justify={"space-between"} gutter={[0, 50]}>
          {footerIcon.map((data) => {
            return (
              <Col span={4}>
                <img src={data} alt="noimage" width={150} />
              </Col>
            );
          })}
        </Row>
        <Divider
          style={{ background: "#213743", padding: "0.5px", width: "80vw" }}
        />
        <Row justify={"space-around"}>
          {footerImage.map((data) => {
            return <img src={data} alt="noimage" width={150} />;
          })}
        </Row>
        <Divider
          style={{ background: "#213743", padding: "0.5px", width: "80vw" }}
        />

        <Row justify="center" style={{ textAlign: "center" }}>
          <Col span={24}>
            <Row justify={"center"}>
              <Text style={{ color: "#a0a0a0" }}>
                Stake is committed to responsible gambling, for more information
                visit{" "}
                <Link href="https://www.gamblingtherapy.org">
                  Gamblingtherapy.org
                </Link>
              </Text>
            </Row>
            <Row justify={"center"}>
              <Text style={{ color: "#a0a0a0", marginTop: 30 }}>
                Stake is owned and operated by Medium Rare N.V., registration
                number: 145353, registered address: Korporaalweg 10, Willemstad,
                Curaçao. Contact us at support@stake.com. Payment agent company
                is Medium Rare Limited with address 7-9 Riga Feraiou, LIZANTIA
                COURT, Office 310, Agioi Omologites, 1087 Nicosia, Cyprus and
                Registration number: HE 410775
              </Text>
            </Row>
            <Row justify={"center"}>
              <Text style={{ color: "#a0a0a0", marginTop: 30 }}>
                Support <Text className="color-white">support@stake.com</Text> |
                Partners <Text className="color-white">partners@stake.com</Text>{" "}
                | Press <Text className="color-white">press@stake.com</Text>
              </Text>
            </Row>
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

export default AppFooter;
