import {
  AppstoreOutlined,
  ClockCircleOutlined,
  CustomerServiceOutlined,
  FireOutlined,
  FormOutlined,
  GiftOutlined,
  GlobalOutlined,
  HistoryOutlined,
  MessageOutlined,
  ShoppingOutlined,
  StarOutlined,
  ThunderboltOutlined,
  TrophyOutlined
} from '@ant-design/icons';
import React, { useState } from 'react';
import { GiHamburgerMenu } from "react-icons/gi";
import { Layout, Menu } from 'antd';
import CustomButton from '../Components/customButton';
import AppHeader from '../appHeader';
import AppContent from '../appContent';
import AppFooter from '../appFooter';
const { Header, Content, Sider, Footer } = Layout;
const siderStyle = {
  overflow: 'auto',
  height: '100vh',
  position: 'fixed',
  insetInlineStart: 0,
  top: 0,
  bottom: 0,
  scrollbarWidth: 'thin',
  scrollbarGutter: 'stable',
};
const items = [
  {
    key: '1',
    icon: <StarOutlined />,
    label: 'Favourites',
  },
  {
    key: '2',
    icon: <HistoryOutlined />,
    label: 'Recent',
  },
  {
    key: '3',
    icon: <ClockCircleOutlined />,
    label: 'Challenges',
  },
  {
    key: '4',
    icon: <ShoppingOutlined />,
    label: 'My Bets',
  },

  // Divider
  { type: 'divider' },

  // Games Section
  {
    key: 'sub1',
    icon: <AppstoreOutlined />,
    label: 'Games',
    children: [
      {
        key: '5',
        icon: <FireOutlined />,
        label: 'Stake Originals',
      },
      {
        key: '6',
        icon: <StarOutlined />,
        label: 'Stake Exclusives',
      },
      {
        key: '7',
        icon: <AppstoreOutlined />,
        label: 'Slots',
      },
      {
        key: '8',
        icon: <AppstoreOutlined />,
        label: 'Live Casino',
      },
      {
        key: '9',
        icon: <AppstoreOutlined />,
        label: 'Game Shows',
      },
      {
        key: '10',
        icon: <AppstoreOutlined />,
        label: 'New Releases',
      },
      {
        key: '11',
        icon: <AppstoreOutlined />,
        label: 'Stake Poker',
      },
      {
        key: '12',
        icon: <AppstoreOutlined />,
        label: 'Bonus Buy',
      },
      {
        key: '13',
        icon: <ThunderboltOutlined />,
        label: 'Enhanced RTP',
      },
      {
        key: '14',
        icon: <AppstoreOutlined />,
        label: 'Table Games',
      },
      {
        key: '15',
        icon: <AppstoreOutlined />,
        label: 'Blackjack',
      },
      {
        key: '16',
        icon: <AppstoreOutlined />,
        label: 'Baccarat',
      },
      {
        key: '17',
        icon: <AppstoreOutlined />,
        label: 'Roulette',
      },
    ],
  },

  // Divider
  { type: 'divider' },

  // Other Sections
  {
    key: '18',
    icon: <AppstoreOutlined />,
    label: 'Providers',
  },
  {
    key: '19',
    icon: <GiftOutlined />,
    label: 'Promotions',
  },
  {
    key: '20',
    icon: <TrophyOutlined />,
    label: 'Affiliate',
  },
  {
    key: '21',
    icon: <TrophyOutlined />,
    label: 'VIP Club',
  },
  {
    key: '22',
    icon: <FormOutlined />,
    label: 'Blog',
  },
  {
    key: '23',
    icon: <MessageOutlined />,
    label: 'Forum',
  },

  // Divider
  { type: 'divider' },

  // Support Section
  {
    key: '24',
    icon: <ThunderboltOutlined />,
    label: 'Sponsorships',
  },
  {
    key: '25',
    icon: <CustomerServiceOutlined />,
    label: 'Responsible Gambling',
  },
  {
    key: '26',
    icon: <CustomerServiceOutlined />,
    label: 'Live Support',
  },
  {
    key: '27',
    icon: <GlobalOutlined />,
    label: 'Language: English',
  },
]
const LayoutComponent = () => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <Layout hasSider>
      <Sider style={siderStyle} trigger={null} collapsible collapsed={collapsed}>
        <div className="demo-logo-vertical" />
        <div className='d-flex g-5'>
          <button
            // icon={}
            onClick={() => setCollapsed(!collapsed)}
            style={{
              fontSize: '16px',
              width: 20,
              height: 20,
              backgroundColor: 'transparent',
              border: 'none',
              // display: collapsed ? 'grid' : 'flex'
            }}
          >
            <GiHamburgerMenu color='#fff' />
          </button>
          <CustomButton backgroundImage={"https://mediumrare.imgix.net/sports-balls-en.jpg?auto=format&w=78"} >
            {collapsed ? '' : 'CASINO'}
          </CustomButton>
          <CustomButton
            backgroundImage={"https://mediumrare.imgix.net/casino-poker-cards-green-en.jpg?auto=format&w=78"}
            activeImage="https://mediumrare.imgix.net/sports-balls-orange-en.jpg?auto=format&w=78"
          >
            {collapsed ? '' : 'SPORT'}
          </CustomButton>

        </div>
        <Menu theme="dark" mode="inline" defaultSelectedKeys={['4']} items={items} />
      </Sider>
      <Layout
        style={{
          marginInlineStart: 200,
        }}
      >
        <Header
         className='headerStyle'
        >
          <AppHeader />
        </Header>
        <Content
          style={{
            overflow: 'initial',
          }}
        >
          <div
            style={{
              padding: '15px 70px',
              textAlign: 'center',
              background: '#1a2c38',
            }}
          >
            <AppContent />
          </div>
        </Content>
        <Footer className='footerStyle'><AppFooter/></Footer>
      </Layout>
    </Layout>
  );
};
export default LayoutComponent;