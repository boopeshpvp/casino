import './App.css';
import LayoutComponent from './layoutComponent';

function App() {
  return (
    <LayoutComponent/>
  );
}

export default App;
